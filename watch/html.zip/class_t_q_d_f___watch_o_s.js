var class_t_q_d_f___watch_o_s =
[
    [ "BUTTON_state", "class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057c", [
      [ "NO_ACTION", "class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057ca9ab9adf3ce9fe568c50055bfb09dd583", null ],
      [ "SHORT_PRESSED", "class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057caf46053aca3878f1a536ea045d4c0121e", null ],
      [ "LONG_PRESSED", "class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057ca0214c69a16df6c4ff0757293c6c3db66", null ]
    ] ],
    [ "LED_power", "class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225a", [
      [ "POWER_DYNAMIC", "class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225aa1719136ea055ae2b88559e6b5fe6aa14", null ],
      [ "POWER_MAXIMUM", "class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225aa37b2afb55861a314c19b22919578d9a6", null ]
    ] ],
    [ "REGISTER_location", "class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6", [
      [ "RUNTIME", "class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6a65422d7d9a51c398c0b893b80b3a9bc3", null ],
      [ "SOURCE", "class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6ad086c450c8b509ba6ebd12daeecbb8d1", null ]
    ] ],
    [ "WATCHDOG_wake_interval", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74", [
      [ "WAKE_EVERY_1S", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74ae0322a6e708da27cecf2fe1f2fc8e548", null ],
      [ "WAKE_EVERY_5S", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a24a459dee24a9a86d284636e7e8bebbf", null ],
      [ "WAKE_EVERY_10S", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a5555d8a050c8e33bce3747758fc14d20", null ],
      [ "WAKE_EVERY_1M", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a6e3dff81f9e26baa4718c708e448d205", null ],
      [ "WAKE_EVERY_5M", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74ab68f12a6eee14478ad53c47cd92d284e", null ],
      [ "WAKE_EVERY_15M", "class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a18c32a45f6ecb15478353e4d800ef927", null ]
    ] ],
    [ "bootloader", "class_t_q_d_f___watch_o_s.html#a6c8b9eafa74132f2df9f46c6ab38ce26", null ],
    [ "BUTTON_getResult", "class_t_q_d_f___watch_o_s.html#adff6ae57098aa6427a51580cec3601ce", null ],
    [ "BUTTON_isPressed", "class_t_q_d_f___watch_o_s.html#a7cd4c5b9d5f8ddb88b17edc0cb474043", null ],
    [ "BUTTON_isSafePressed", "class_t_q_d_f___watch_o_s.html#a3a355bd876ad7ca98c68e8fc63ab9b28", null ],
    [ "config", "class_t_q_d_f___watch_o_s.html#aeb2b56fa24344c2a47b2a6e597ffe4a7", null ],
    [ "LED_clear", "class_t_q_d_f___watch_o_s.html#a7aa7ec0224447307f0863b2767ce6418", null ],
    [ "LED_setBrightnessMax", "class_t_q_d_f___watch_o_s.html#aeaec7ef77bba79f3792cddda114ff529", null ],
    [ "LED_setPowerLimit", "class_t_q_d_f___watch_o_s.html#a2367439665fdde2cee35c5fdc5a053b6", null ],
    [ "LED_show", "class_t_q_d_f___watch_o_s.html#a16d5aab46f3f431fea5579a4ae6a28f9", null ],
    [ "LED_test_deadlock", "class_t_q_d_f___watch_o_s.html#ac5fe5e1cca51ae777ff21da5fcca9952", null ],
    [ "LED_toggle", "class_t_q_d_f___watch_o_s.html#a0c2327f357caad63a869e736b9685f1f", null ],
    [ "LED_write", "class_t_q_d_f___watch_o_s.html#aee16bf16dc94b155fe3e4e2bdf22e006", null ],
    [ "LED_write", "class_t_q_d_f___watch_o_s.html#a959f003d4d8ebf5d4c50ad291b9cea07", null ],
    [ "main", "class_t_q_d_f___watch_o_s.html#a9eba45bb686da79be0bf68f49c1b691b", null ],
    [ "REGISTER_read", "class_t_q_d_f___watch_o_s.html#a85c525d7ff22da7ba7674402e1e0022e", null ],
    [ "REGISTER_write", "class_t_q_d_f___watch_o_s.html#aa801b0854ba8947c51554e2ff71a15c1", null ],
    [ "reset", "class_t_q_d_f___watch_o_s.html#a80923413d182610e83ec23e091513cd9", null ],
    [ "RTC_fineTune", "class_t_q_d_f___watch_o_s.html#a978ac71ca93fbbb893a6755fbef03a69", null ],
    [ "RTC_getDay", "class_t_q_d_f___watch_o_s.html#ad10fb76e1048d128658c7141adeec5a6", null ],
    [ "RTC_getHour", "class_t_q_d_f___watch_o_s.html#ab33ea670c3840f4e16ba0905f4fe48f7", null ],
    [ "RTC_getMinute", "class_t_q_d_f___watch_o_s.html#a3efb768199e808b9a3e4e0c3de8de71c", null ],
    [ "RTC_getMonth", "class_t_q_d_f___watch_o_s.html#a786998230c32f798fde52a647baf699e", null ],
    [ "RTC_getSecond", "class_t_q_d_f___watch_o_s.html#a1a45ab0e83a3c64c1e69bd609cb4344e", null ],
    [ "RTC_getYear", "class_t_q_d_f___watch_o_s.html#a220923562afaab2058ae345983cba500", null ],
    [ "RTC_initialDate", "class_t_q_d_f___watch_o_s.html#ac529a38ac060cd51ce3b002c24ea0251", null ],
    [ "RTC_initialTime", "class_t_q_d_f___watch_o_s.html#a6cbc921da06c8fd7d1f70c9acba7031d", null ],
    [ "RTC_setDate", "class_t_q_d_f___watch_o_s.html#a0576815b66e6e88cf914f3bddadcd45b", null ],
    [ "RTC_setTime", "class_t_q_d_f___watch_o_s.html#ae699891be1af2dd9fcc9a338ac9e58c8", null ],
    [ "RTC_update", "class_t_q_d_f___watch_o_s.html#acfaf9c28225e0d250a6f8955913fabb1", null ],
    [ "shutdown", "class_t_q_d_f___watch_o_s.html#a1f63496e23f81bbd508f44e34d8d0775", null ],
    [ "WATCHDOG_isWakeUp", "class_t_q_d_f___watch_o_s.html#a132fe7575e3d6f772a954c3b2c0e0acc", null ],
    [ "WATCHDOG_setRoutine", "class_t_q_d_f___watch_o_s.html#a50fba5681687d98daa2f1ac92ee7830d", null ]
];