var _t_q_d_f___watch_o_s_8h =
[
    [ "TQDF_WatchOS", "class_t_q_d_f___watch_o_s.html", "class_t_q_d_f___watch_o_s" ]
];