var index =
[
    [ "Are you sure it can be used as a normal watch?", "index.html#autotoc_md1", null ],
    [ "Wait, Do I Need to develop the software by myself?", "index.html#autotoc_md2", null ],
    [ "Compatible Hardware", "index.html#autotoc_md3", [
      [ "AEONF mark 6", "index.html#autotoc_md4", null ]
    ] ],
    [ "How to read the Time?", "index.html#autotoc_md5", [
      [ "MODE 1: The standard", "index.html#autotoc_md6", null ]
    ] ],
    [ "Adjusting the time?", "index.html#autotoc_md7", [
      [ "Menu entry point", "index.html#autotoc_md8", null ],
      [ "The button modes", "index.html#autotoc_md9", [
        [ "Configure the time", "index.html#autotoc_md10", null ],
        [ "Prepare the parameters:", "index.html#autotoc_md11", null ],
        [ "Intuitive way:", "index.html#autotoc_md12", null ],
        [ "Here are the detailed steps:", "index.html#autotoc_md13", null ]
      ] ]
    ] ],
    [ "Advanced Menu", "index.html#autotoc_md14", null ],
    [ "Other Things", "index.html#autotoc_md15", null ],
    [ "SUWUN!", "index.html#autotoc_md16", null ]
];