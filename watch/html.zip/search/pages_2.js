var searchData=
[
  ['the_20development_0',['The Development',['../md__d____g_i_t__p_r_o_j_e_c_t___p_r_o_j_e_c_t__t_q_d_f__watch__t_q_d_f__watch__full_lib__t_q_d_f__watch_o_s_docs_firmware.html',1,'']]],
  ['tqdf_5fwatchos_1',['TQDF_WatchOS',['../index.html',1,'']]]
];
