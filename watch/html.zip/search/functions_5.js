var searchData=
[
  ['shutdown_0',['shutdown',['../class_t_q_d_f___watch_o_s.html#a1f63496e23f81bbd508f44e34d8d0775',1,'TQDF_WatchOS']]]
];
