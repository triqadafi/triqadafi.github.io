var searchData=
[
  ['register_5flocation_0',['REGISTER_location',['../class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6',1,'TQDF_WatchOS']]]
];
