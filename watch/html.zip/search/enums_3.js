var searchData=
[
  ['watchdog_5fwake_5finterval_0',['WATCHDOG_wake_interval',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74',1,'TQDF_WatchOS']]]
];
