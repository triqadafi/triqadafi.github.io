var searchData=
[
  ['tqdf_5fwatchos_2eh_0',['TQDF_WatchOS.h',['../_t_q_d_f___watch_o_s_8h.html',1,'']]]
];
