var searchData=
[
  ['main_0',['main',['../class_t_q_d_f___watch_o_s.html#a9eba45bb686da79be0bf68f49c1b691b',1,'TQDF_WatchOS']]]
];
