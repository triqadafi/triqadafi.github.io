var searchData=
[
  ['runtime_0',['RUNTIME',['../class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6a65422d7d9a51c398c0b893b80b3a9bc3',1,'TQDF_WatchOS']]]
];
