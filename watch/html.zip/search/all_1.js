var searchData=
[
  ['config_0',['config',['../class_t_q_d_f___watch_o_s.html#aeb2b56fa24344c2a47b2a6e597ffe4a7',1,'TQDF_WatchOS']]]
];
