var searchData=
[
  ['tqdf_5fwatchos_0',['TQDF_WatchOS',['../class_t_q_d_f___watch_o_s.html',1,'']]]
];
