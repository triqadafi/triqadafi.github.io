var searchData=
[
  ['led_5fclear_0',['LED_clear',['../class_t_q_d_f___watch_o_s.html#a7aa7ec0224447307f0863b2767ce6418',1,'TQDF_WatchOS']]],
  ['led_5fpower_1',['LED_power',['../class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225a',1,'TQDF_WatchOS']]],
  ['led_5fsetbrightnessmax_2',['LED_setBrightnessMax',['../class_t_q_d_f___watch_o_s.html#aeaec7ef77bba79f3792cddda114ff529',1,'TQDF_WatchOS']]],
  ['led_5fsetpowerlimit_3',['LED_setPowerLimit',['../class_t_q_d_f___watch_o_s.html#a2367439665fdde2cee35c5fdc5a053b6',1,'TQDF_WatchOS']]],
  ['led_5fshow_4',['LED_show',['../class_t_q_d_f___watch_o_s.html#a16d5aab46f3f431fea5579a4ae6a28f9',1,'TQDF_WatchOS']]],
  ['led_5ftest_5fdeadlock_5',['LED_test_deadlock',['../class_t_q_d_f___watch_o_s.html#ac5fe5e1cca51ae777ff21da5fcca9952',1,'TQDF_WatchOS']]],
  ['led_5ftoggle_6',['LED_toggle',['../class_t_q_d_f___watch_o_s.html#a0c2327f357caad63a869e736b9685f1f',1,'TQDF_WatchOS']]],
  ['led_5fwrite_7',['LED_write',['../class_t_q_d_f___watch_o_s.html#aee16bf16dc94b155fe3e4e2bdf22e006',1,'TQDF_WatchOS::LED_write(int index, bool state)'],['../class_t_q_d_f___watch_o_s.html#a959f003d4d8ebf5d4c50ad291b9cea07',1,'TQDF_WatchOS::LED_write(int type, int index, bool state)']]],
  ['long_5fpressed_8',['LONG_PRESSED',['../class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057ca0214c69a16df6c4ff0757293c6c3db66',1,'TQDF_WatchOS']]]
];
