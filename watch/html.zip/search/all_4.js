var searchData=
[
  ['no_5faction_0',['NO_ACTION',['../class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057ca9ab9adf3ce9fe568c50055bfb09dd583',1,'TQDF_WatchOS']]]
];
