var searchData=
[
  ['wake_5fevery_5f10s_0',['WAKE_EVERY_10S',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a5555d8a050c8e33bce3747758fc14d20',1,'TQDF_WatchOS']]],
  ['wake_5fevery_5f15m_1',['WAKE_EVERY_15M',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a18c32a45f6ecb15478353e4d800ef927',1,'TQDF_WatchOS']]],
  ['wake_5fevery_5f1m_2',['WAKE_EVERY_1M',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a6e3dff81f9e26baa4718c708e448d205',1,'TQDF_WatchOS']]],
  ['wake_5fevery_5f1s_3',['WAKE_EVERY_1S',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74ae0322a6e708da27cecf2fe1f2fc8e548',1,'TQDF_WatchOS']]],
  ['wake_5fevery_5f5m_4',['WAKE_EVERY_5M',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74ab68f12a6eee14478ad53c47cd92d284e',1,'TQDF_WatchOS']]],
  ['wake_5fevery_5f5s_5',['WAKE_EVERY_5S',['../class_t_q_d_f___watch_o_s.html#a814147015c8047464c7c790651f44b74a24a459dee24a9a86d284636e7e8bebbf',1,'TQDF_WatchOS']]]
];
