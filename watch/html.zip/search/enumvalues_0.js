var searchData=
[
  ['long_5fpressed_0',['LONG_PRESSED',['../class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057ca0214c69a16df6c4ff0757293c6c3db66',1,'TQDF_WatchOS']]]
];
