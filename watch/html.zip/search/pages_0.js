var searchData=
[
  ['tqdf_5fwatchos_0',['TQDF_WatchOS',['../index.html',1,'']]]
];
