var searchData=
[
  ['register_5fread_0',['REGISTER_read',['../class_t_q_d_f___watch_o_s.html#a85c525d7ff22da7ba7674402e1e0022e',1,'TQDF_WatchOS']]],
  ['register_5fwrite_1',['REGISTER_write',['../class_t_q_d_f___watch_o_s.html#aa801b0854ba8947c51554e2ff71a15c1',1,'TQDF_WatchOS']]],
  ['reset_2',['reset',['../class_t_q_d_f___watch_o_s.html#a80923413d182610e83ec23e091513cd9',1,'TQDF_WatchOS']]],
  ['rtc_5ffinetune_3',['RTC_fineTune',['../class_t_q_d_f___watch_o_s.html#a978ac71ca93fbbb893a6755fbef03a69',1,'TQDF_WatchOS']]],
  ['rtc_5fgetday_4',['RTC_getDay',['../class_t_q_d_f___watch_o_s.html#ad10fb76e1048d128658c7141adeec5a6',1,'TQDF_WatchOS']]],
  ['rtc_5fgethour_5',['RTC_getHour',['../class_t_q_d_f___watch_o_s.html#ab33ea670c3840f4e16ba0905f4fe48f7',1,'TQDF_WatchOS']]],
  ['rtc_5fgetminute_6',['RTC_getMinute',['../class_t_q_d_f___watch_o_s.html#a3efb768199e808b9a3e4e0c3de8de71c',1,'TQDF_WatchOS']]],
  ['rtc_5fgetmonth_7',['RTC_getMonth',['../class_t_q_d_f___watch_o_s.html#a786998230c32f798fde52a647baf699e',1,'TQDF_WatchOS']]],
  ['rtc_5fgetsecond_8',['RTC_getSecond',['../class_t_q_d_f___watch_o_s.html#a1a45ab0e83a3c64c1e69bd609cb4344e',1,'TQDF_WatchOS']]],
  ['rtc_5fgetyear_9',['RTC_getYear',['../class_t_q_d_f___watch_o_s.html#a220923562afaab2058ae345983cba500',1,'TQDF_WatchOS']]],
  ['rtc_5finitialdate_10',['RTC_initialDate',['../class_t_q_d_f___watch_o_s.html#ac529a38ac060cd51ce3b002c24ea0251',1,'TQDF_WatchOS']]],
  ['rtc_5finitialtime_11',['RTC_initialTime',['../class_t_q_d_f___watch_o_s.html#a6cbc921da06c8fd7d1f70c9acba7031d',1,'TQDF_WatchOS']]],
  ['rtc_5fsetdate_12',['RTC_setDate',['../class_t_q_d_f___watch_o_s.html#a0576815b66e6e88cf914f3bddadcd45b',1,'TQDF_WatchOS']]],
  ['rtc_5fsettime_13',['RTC_setTime',['../class_t_q_d_f___watch_o_s.html#ae699891be1af2dd9fcc9a338ac9e58c8',1,'TQDF_WatchOS']]],
  ['rtc_5fupdate_14',['RTC_update',['../class_t_q_d_f___watch_o_s.html#acfaf9c28225e0d250a6f8955913fabb1',1,'TQDF_WatchOS']]]
];
