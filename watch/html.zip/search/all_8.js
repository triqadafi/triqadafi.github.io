var searchData=
[
  ['tqdf_5fwatchos_0',['TQDF_WatchOS',['../index.html',1,'(Global Namespace)'],['../class_t_q_d_f___watch_o_s.html',1,'TQDF_WatchOS']]],
  ['tqdf_5fwatchos_2eh_1',['TQDF_WatchOS.h',['../_t_q_d_f___watch_o_s_8h.html',1,'']]]
];
