var searchData=
[
  ['watchdog_5fiswakeup_0',['WATCHDOG_isWakeUp',['../class_t_q_d_f___watch_o_s.html#a132fe7575e3d6f772a954c3b2c0e0acc',1,'TQDF_WatchOS']]],
  ['watchdog_5fsetroutine_1',['WATCHDOG_setRoutine',['../class_t_q_d_f___watch_o_s.html#a50fba5681687d98daa2f1ac92ee7830d',1,'TQDF_WatchOS']]]
];
