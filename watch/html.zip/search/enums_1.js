var searchData=
[
  ['led_5fpower_0',['LED_power',['../class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225a',1,'TQDF_WatchOS']]]
];
