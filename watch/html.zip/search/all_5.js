var searchData=
[
  ['power_5fdynamic_0',['POWER_DYNAMIC',['../class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225aa1719136ea055ae2b88559e6b5fe6aa14',1,'TQDF_WatchOS']]],
  ['power_5fmaximum_1',['POWER_MAXIMUM',['../class_t_q_d_f___watch_o_s.html#a0498148881c4674b319bbb9d88d0225aa37b2afb55861a314c19b22919578d9a6',1,'TQDF_WatchOS']]]
];
