var searchData=
[
  ['short_5fpressed_0',['SHORT_PRESSED',['../class_t_q_d_f___watch_o_s.html#a281146658c1e7750c052ec06be61057caf46053aca3878f1a536ea045d4c0121e',1,'TQDF_WatchOS']]],
  ['shutdown_1',['shutdown',['../class_t_q_d_f___watch_o_s.html#a1f63496e23f81bbd508f44e34d8d0775',1,'TQDF_WatchOS']]],
  ['source_2',['SOURCE',['../class_t_q_d_f___watch_o_s.html#a22375d6b2c5120dfa20bacc753ae17e6ad086c450c8b509ba6ebd12daeecbb8d1',1,'TQDF_WatchOS']]]
];
